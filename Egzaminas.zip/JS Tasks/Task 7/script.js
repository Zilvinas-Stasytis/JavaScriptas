/* ------------------------------ TASK 7 -----------------------------------
Turimas "audi" objektas.

Parašykite funkciją "showObjectKeys", kuri kaip argumentą priims objektą 
ir grąžins visus jo "key" masyve.
-------------------------------------------------------------------------- */
const audi = {
  make: 'audi',
  model: 'A6',
  year: 2005,
  color: 'white'
};
let key = [];
function showObjectKeys(key) {

  // console.log( Object.keys(audi));
 key.push(Object.keys(audi));
 console.log(key);
}
showObjectKeys(key);
