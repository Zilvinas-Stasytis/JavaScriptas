function multiplication(a, b) {
  return a * b;
}
